/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositorios;

/**
 *
 * @author adria
 */
import java.sql.*;
import java.util.ArrayList;
import modelos.Quarto;

public class RepositorioQuarto {
    private final String jdbcUrl = "jdbc:mysql://localhost:3306/hotel_reservas?useSSL=false&serverTimezone=UTC";
    private final String username = "root";
    private final String password = "root";

    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver não encontrado: " + e.getMessage());
        }
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    public void inserirQuarto(Quarto quarto) {
        String sql = "INSERT INTO quarto (numero, tipo, preco_diaria) VALUES (?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, quarto.getNumero());
            stmt.setString(2, quarto.getTipo());
            stmt.setDouble(3, quarto.getPrecoDiaria());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erro ao inserir quarto: " + e.getMessage());
        }
    }

    public ArrayList<Quarto> listarQuartos() {
        ArrayList<Quarto> lista = new ArrayList<>();
        String sql = "SELECT * FROM quarto";
        try (Connection conn = conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Quarto q = new Quarto();
                q.setId(rs.getInt("id"));
                q.setNumero(rs.getInt("numero"));
                q.setTipo(rs.getString("tipo"));
                q.setPrecoDiaria(rs.getDouble("preco_diaria"));
                lista.add(q);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar quartos: " + e.getMessage());
        }
        return lista;
    }

    public boolean excluirQuarto(int id) {
        String sql = "DELETE FROM quarto WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao excluir quarto: " + e.getMessage());
        }
        return false;
    }

    public Quarto buscarQuartoPorId(int id) {
        String sql = "SELECT * FROM quarto WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Quarto quarto = new Quarto();
                quarto.setId(rs.getInt("id"));
                quarto.setNumero(rs.getInt("numero"));
                quarto.setTipo(rs.getString("tipo"));
                quarto.setPrecoDiaria(rs.getDouble("preco_diaria"));
                return quarto;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar quarto: " + e.getMessage());
        }
        return null;
    }
}
