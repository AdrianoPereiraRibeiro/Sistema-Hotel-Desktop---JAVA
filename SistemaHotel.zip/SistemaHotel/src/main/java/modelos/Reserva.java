/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.util.Date;
import java.util.List;

/**
 *
 * @author adria
 */
public class Reserva {
    private int id;
    private Cliente cliente;
    private Date dataCheckin;
    private Date dataCheckout;
    private Quarto quarto;

    public Reserva() {
    }

    public Reserva(Cliente cliente, Date dataCheckin, Date dataCheckout, Quarto quarto) {
        this.cliente = cliente;
        this.dataCheckin = dataCheckin;
        this.dataCheckout = dataCheckout;
        this.quarto = quarto;
    }

    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Date getDataCheckin() { return dataCheckin; }
    public void setDataCheckin(Date dataCheckin) { this.dataCheckin = dataCheckin; }

    public Date getDataCheckout() { return dataCheckout; }
    public void setDataCheckout(Date dataCheckout) { this.dataCheckout = dataCheckout; }


    public Quarto getQuarto() { return quarto; }
    public void setQuarto(Quarto quarto) { this.quarto = quarto; }
    
}
