/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

/**
 *
 * @author adria
 */

import java.util.ArrayList;
import modelos.Cliente;
import repositorios.RepositorioCliente;


public class ControladorCliente {
    private RepositorioCliente repositorio;

    public ControladorCliente() {
        this.repositorio = new RepositorioCliente();
    }

    public void cadastrarCliente(String nome, String cpf) {
        Cliente cliente = new Cliente(nome, cpf);
        repositorio.inserirCliente(cliente);
    }

    public ArrayList<Cliente> listarClientes() {
        return repositorio.listarClientes();
    }

    public boolean excluirCliente(int id) {
        return repositorio.excluirCliente(id);
    }

    public Cliente buscarCliente(int id) {
        return repositorio.buscarClientePorId(id);
    }
}
