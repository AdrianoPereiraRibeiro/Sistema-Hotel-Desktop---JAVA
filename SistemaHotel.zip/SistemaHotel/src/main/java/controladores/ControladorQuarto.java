/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

/**
 *
 * @author adria
 */
import java.util.ArrayList;
import modelos.Quarto;
import repositorios.RepositorioQuarto;

public class ControladorQuarto {
    private RepositorioQuarto repositorio;

    public ControladorQuarto() {
        this.repositorio = new RepositorioQuarto();
    }

    public void cadastrarQuarto(int numero, String tipo, double precoDiaria) {
        Quarto quarto = new Quarto(numero, tipo, precoDiaria);
        repositorio.inserirQuarto(quarto);
    }

    public ArrayList<Quarto> listarQuartos() {
        return repositorio.listarQuartos();
    }

    public boolean excluirQuarto(int id) {
        return repositorio.excluirQuarto(id);
    }

    public Quarto buscarQuarto(int id) {
        return repositorio.buscarQuartoPorId(id);
    }
}
