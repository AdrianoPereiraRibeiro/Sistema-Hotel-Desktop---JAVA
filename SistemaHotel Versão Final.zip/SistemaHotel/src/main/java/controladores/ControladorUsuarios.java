/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import modelos.Usuario;
import repositorios.RepositorioUsuario;

/**
 *
 * @author adria
 */
public class ControladorUsuarios {
    private RepositorioUsuario repositorio;

    public ControladorUsuarios() {
        this.repositorio = new RepositorioUsuario();
    }

    public boolean autenticar(String login, String senha) {
        return repositorio.autenticar(login, senha);
    }
    
   public void cadastrar(String login,String senha){
   Usuario usuario = new Usuario(login,senha);
   repositorio.cadastrar(usuario);
   
   } 
    
}
