/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import modelos.Cliente;
import modelos.Quarto;
import modelos.Reserva;
import repositorios.RepositorioReserva;

/**
 *
 * @author adria
 */
public class ControladorReserva {
    private RepositorioReserva repositorio;

    public ControladorReserva() {
        this.repositorio = new RepositorioReserva();
    }

    public void cadastrarReserva(Cliente cliente, Date checkin, Date checkout, Quarto quarto) {
        Reserva reserva = new Reserva(cliente, checkin, checkout, quarto);
        repositorio.inserirReserva(reserva);
    }

    public ArrayList<Reserva> listarReservas() {
        return repositorio.listarReservas();
    }

    public boolean excluirReserva(int id) {
        return repositorio.excluirReserva(id);
    }
}
