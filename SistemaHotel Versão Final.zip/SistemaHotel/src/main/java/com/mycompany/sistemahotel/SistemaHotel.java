/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemahotel;

import controladores.ControladorCliente;
import controladores.ControladorQuarto;
import controladores.ControladorReserva;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import modelos.Cliente;
import modelos.Quarto;
import modelos.Reserva;

/**
 *
 * @author adria
 */
public class SistemaHotel {

    public static void main(String[] args) {
        TelaILogin telaLogin = new TelaILogin();
        telaLogin.setVisible(true);
}
}