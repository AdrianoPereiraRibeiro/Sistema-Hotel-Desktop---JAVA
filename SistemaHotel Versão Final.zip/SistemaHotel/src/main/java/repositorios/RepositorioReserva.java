/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositorios;

/**
 *
 * @author adria
 */
import java.sql.*;
import java.util.ArrayList;
import modelos.Cliente;
import modelos.Quarto;
import modelos.Reserva;

public class RepositorioReserva {
    private final String jdbcUrl = "jdbc:mysql://localhost:3306/hotel_reservas?useSSL=false&serverTimezone=UTC";
    private final String username = "root";
    private final String password = "root";

    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver não encontrado: " + e.getMessage());
        }
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    public void inserirReserva(Reserva reserva) {
        String sql = "INSERT INTO reserva (id_cliente, data_checkin, data_checkout) VALUES (?, ?, ?)";
        try (Connection conn = conectar();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, reserva.getCliente().getId());
            stmt.setDate(2, new java.sql.Date(reserva.getDataCheckin().getTime()));
            stmt.setDate(3, new java.sql.Date(reserva.getDataCheckout().getTime()));
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int reservaId = rs.getInt(1);
                Quarto q = reserva.getQuarto();
                if (q != null) {
                    String assoc = "INSERT INTO reserva_quarto (id_reserva, id_quarto) VALUES (?, ?)";
                    try (PreparedStatement assocStmt = conn.prepareStatement(assoc)) {
                        assocStmt.setInt(1, reservaId);
                        assocStmt.setInt(2, q.getId());
                        assocStmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao inserir reserva: " + e.getMessage());
        }
    }

    public ArrayList<Reserva> listarReservas() {
        ArrayList<Reserva> lista = new ArrayList<>();
        String sql = "SELECT r.id, r.data_checkin, r.data_checkout, c.id AS cliente_id, c.nome, c.cpf, rq.id_quarto, q.numero, q.tipo, q.preco_diaria FROM reserva r JOIN cliente c ON r.id_cliente = c.id LEFT JOIN reserva_quarto rq ON r.id = rq.id_reserva LEFT JOIN quarto q ON rq.id_quarto = q.id";
        try (Connection conn = conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setCpf(rs.getString("cpf"));

                Quarto quarto = new Quarto();
                quarto.setId(rs.getInt("id_quarto"));
                quarto.setNumero(rs.getInt("numero"));
                quarto.setTipo(rs.getString("tipo"));
                quarto.setPrecoDiaria(rs.getDouble("preco_diaria"));

                Reserva reserva = new Reserva();
                reserva.setId(rs.getInt("id"));
                reserva.setCliente(cliente);
                reserva.setDataCheckin(rs.getDate("data_checkin"));
                reserva.setDataCheckout(rs.getDate("data_checkout"));
                reserva.setQuarto(quarto);

                lista.add(reserva);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar reservas: " + e.getMessage());
        }
        return lista;
    }
public Reserva buscarPorId(int id) {
    String sql = "SELECT r.id, r.data_checkin, r.data_checkout, " +
                 "c.id AS cliente_id, c.nome, c.cpf, " +
                 "q.id AS id_quarto, q.numero, q.tipo, q.preco_diaria " +
                 "FROM reserva r " +
                 "JOIN cliente c ON r.id_cliente = c.id " +
                 "LEFT JOIN reserva_quarto rq ON r.id = rq.id_reserva " +
                 "LEFT JOIN quarto q ON rq.id_quarto = q.id " +
                 "WHERE r.id = ?";

    try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            Cliente cliente = new Cliente();
            cliente.setId(rs.getInt("cliente_id"));
            cliente.setNome(rs.getString("nome"));
            cliente.setCpf(rs.getString("cpf"));

            Quarto quarto = new Quarto();
            quarto.setId(rs.getInt("id_quarto"));
            quarto.setNumero(rs.getInt("numero"));
            quarto.setTipo(rs.getString("tipo"));
            quarto.setPrecoDiaria(rs.getDouble("preco_diaria"));

            Reserva reserva = new Reserva();
            reserva.setId(rs.getInt("id"));
            reserva.setCliente(cliente);
            reserva.setDataCheckin(rs.getDate("data_checkin"));
            reserva.setDataCheckout(rs.getDate("data_checkout"));
            reserva.setQuarto(quarto);

            return reserva;
        }
    } catch (SQLException e) {
        System.err.println("Erro ao buscar reserva por ID: " + e.getMessage());
    }
    return null;
}

    public boolean excluirReserva(int id) {
        String sqlAssoc = "DELETE FROM reserva_quarto WHERE id_reserva = ?";
        String sqlReserva = "DELETE FROM reserva WHERE id = ?";
        try (Connection conn = conectar()) {
            try (PreparedStatement stmtAssoc = conn.prepareStatement(sqlAssoc)) {
                stmtAssoc.setInt(1, id);
                stmtAssoc.executeUpdate();
            }
            try (PreparedStatement stmtReserva = conn.prepareStatement(sqlReserva)) {
                stmtReserva.setInt(1, id);
                return stmtReserva.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao excluir reserva: " + e.getMessage());
        }
        return false;
    }
}
