/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositorios;

/**
 *
 * @author adria
 */

import java.sql.*;
import modelos.Usuario;
public class RepositorioUsuario {
    private final String jdbcUrl = "jdbc:mysql://localhost:3306/hotel_reservas?useSSL=false&serverTimezone=UTC";
    private final String username = "root";
    private final String password = "root";

    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver não encontrado: " + e.getMessage());
        }
        return DriverManager.getConnection(jdbcUrl, username, password);
    }

    public boolean autenticar(String login, String senha) {
        String sql = "SELECT * FROM usuario WHERE login = ? AND senha = ?";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, login);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setLogin(rs.getString("login"));
                usuario.setSenha(rs.getString("senha"));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao autenticar usuário: " + e.getMessage());
        }
        return false;
    }
    
    public boolean cadastrar(Usuario usuario) {
    String sql = "INSERT INTO usuario (login, senha) VALUES (?, ?)";
    try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, usuario.getLogin());
        stmt.setString(2, usuario.getSenha());
        int linhasAfetadas = stmt.executeUpdate();
        return linhasAfetadas > 0;
    } catch (SQLException e) {
        System.err.println("Erro ao cadastrar usuário: " + e.getMessage());
        return false;
    }
}

}
